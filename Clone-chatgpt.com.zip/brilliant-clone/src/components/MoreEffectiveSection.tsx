"use client";

export function MoreEffectiveSection() {
  return (
    <section className="py-20 px-6 bg-white">
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
        <div className="relative h-80 w-full">
          {/* Interactive visual placeholder */}
          <div className="absolute inset-0 rounded-xl bg-gray-50 flex items-center justify-center overflow-hidden">
            <div className="relative">
              {/* Simplified formula/math illustration */}
              <svg width="240" height="240" viewBox="0 0 240 240" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-60">
                <circle cx="120" cy="120" r="100" stroke="#2ec95d" strokeWidth="2" strokeDasharray="8 8" />
                <circle cx="70" cy="120" r="30" fill="#e2c438" />
                <circle cx="170" cy="120" r="30" fill="#9962ec" />
                <line x1="70" y1="120" x2="170" y2="120" stroke="#2ec95d" strokeWidth="3" />
                <line x1="120" y1="70" x2="120" y2="170" stroke="#2ec95d" strokeWidth="3" />
              </svg>

              {/* Particles */}
              <div className="absolute top-1/3 right-1/3 w-3 h-3 rounded-full bg-brilliant-primary animate-ping opacity-75"></div>
              <div className="absolute bottom-1/3 left-1/3 w-2 h-2 rounded-full bg-brilliant-secondary animate-ping opacity-75" style={{ animationDelay: "0.5s" }}></div>
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            More effective.<br />
            More fun.
          </h2>
          <p className="text-lg text-zinc-700 mb-6">
            Brilliant's interactive approach teaches you to think, not memorize.
          </p>
        </div>
      </div>
    </section>
  );
}
