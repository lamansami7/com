"use client";

import Image from "next/image";

export function ConceptsSection() {
  return (
    <section className="py-20 px-6 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
        <div className="relative h-80 w-full">
          {/* Placeholder for an interactive concept visual */}
          <div className="absolute inset-0 rounded-xl bg-gray-100 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-24 h-24 text-brilliant-purple/30">
              <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zM9 7.5A.75.75 0 009 9h1.5c.98 0 1.813.626 2.122 1.5H9A.75.75 0 009 12h3.622a2.251 2.251 0 01-2.122 1.5H9a.75.75 0 00-.53 1.28l3 3a.75.75 0 101.06-1.06L10.8 14.988A3.752 3.752 0 0014.175 12H15a.75.75 0 000-1.5h-.825A3.733 3.733 0 0013.5 9H15a.75.75 0 000-1.5H9z" clipRule="evenodd" />
            </svg>
          </div>
        </div>

        <div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Concepts<br />
            that click
          </h2>
          <p className="text-lg text-zinc-700 mb-6">
            Interactive lessons make even complex ideas easy to grasp. Instant, custom feedback accelerates your understanding.
          </p>
        </div>
      </div>
    </section>
  );
}
