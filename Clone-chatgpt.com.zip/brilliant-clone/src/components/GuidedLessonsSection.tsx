"use client";

export function GuidedLessonsSection() {
  return (
    <section className="py-20 px-6 bg-gradient-to-b from-brilliant-lightBg to-white">
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
        <div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Guided bite-sized lessons
          </h2>
          <p className="text-lg text-zinc-700 mb-6">
            Stay on track, see your progress, and build your problem-solving skills one concept at a time.
          </p>
        </div>

        <div className="relative">
          {/* Visual representation of learning path with steps */}
          <div className="w-full h-80 bg-white rounded-xl shadow-md p-6 relative">
            {/* Path visual with diamond shapes */}
            <div className="absolute top-1/4 left-1/4 w-12 h-12 rounded-lg bg-brilliant-primary rotate-45 flex items-center justify-center">
              <span className="text-white font-bold -rotate-45">1</span>
            </div>
            <div className="absolute top-1/2 left-1/2 w-12 h-12 rounded-lg bg-gray-300 rotate-45 flex items-center justify-center">
              <span className="text-white font-bold -rotate-45">2</span>
            </div>
            <div className="absolute bottom-1/4 right-1/4 w-12 h-12 rounded-lg bg-gray-300 rotate-45 flex items-center justify-center">
              <span className="text-white font-bold -rotate-45">3</span>
            </div>

            {/* Lines connecting steps */}
            <div className="absolute top-[30%] left-[35%] w-[20%] h-[2px] bg-gray-300 rotate-45"></div>
            <div className="absolute top-[55%] left-[55%] w-[20%] h-[2px] bg-gray-300 rotate-45"></div>

            {/* Progress indicator */}
            <div className="absolute bottom-6 left-6 right-6 h-6 bg-gray-100 rounded-full overflow-hidden">
              <div className="h-full w-1/3 bg-brilliant-primary rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
