"use client";

import { Button } from "./ui/button";
import Image from "next/image";

export function HeroSection() {
  return (
    <div className="relative min-h-[70vh] flex flex-col items-center justify-center text-center px-4 py-16 overflow-hidden">
      {/* Background elements that simulate the nodes and connections from the original */}
      <div className="absolute inset-0 z-0 opacity-40">
        {/* We'll simulate the background graph elements with some simple shapes */}
        <div className="absolute top-1/4 left-1/4 w-4 h-4 rounded-full bg-brilliant-secondary"></div>
        <div className="absolute top-1/3 right-1/3 w-3 h-3 rounded-full bg-brilliant-primary"></div>
        <div className="absolute bottom-1/3 left-1/2 w-5 h-5 rounded-full bg-brilliant-purple"></div>
        <div className="absolute top-1/2 right-1/4 w-4 h-4 rounded-full bg-blue-400"></div>
        {/* Lines connecting the dots */}
        <div className="absolute top-[30%] left-[30%] w-[20%] h-[1px] bg-gray-300 rotate-45"></div>
        <div className="absolute top-[40%] right-[35%] w-[15%] h-[1px] bg-gray-300 -rotate-30"></div>
        <div className="absolute bottom-[40%] left-[45%] w-[10%] h-[1px] bg-gray-300 rotate-15"></div>
      </div>

      <div className="relative z-10 max-w-4xl">
        <h1 className="text-6xl md:text-8xl font-bold mb-6">
          Learn
          <br />
          by doing
        </h1>
        <p className="text-xl mb-8 text-zinc-700 dark:text-zinc-300 max-w-2xl mx-auto">
          Interactive problem solving that's effective and fun.
          <br />
          Get smarter in 15 minutes a day.
        </p>
        <Button className="bg-brilliant-primary hover:bg-brilliant-primary/90 text-white rounded-full px-8 py-6 text-lg">
          Get Started
        </Button>
      </div>
    </div>
  );
}
