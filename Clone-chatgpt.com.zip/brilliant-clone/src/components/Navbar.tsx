"use client";

import Link from "next/link";
import { Button } from "./ui/button";
import Image from "next/image";

export function Navbar() {
  return (
    <header className="flex items-center justify-between py-4 px-6 md:px-12">
      <div>
        <Link href="/">
          <div className="font-bold text-2xl flex items-center">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-zinc-900 to-zinc-900 dark:from-zinc-100 dark:to-zinc-100">
              Brilliant
            </span>
          </div>
        </Link>
      </div>
      <div className="flex items-center gap-4">
        <Link href="/login" className="text-zinc-700 hover:text-zinc-900 dark:text-zinc-300 dark:hover:text-zinc-100">
          Log in
        </Link>
        <Button className="bg-brilliant-primary hover:bg-brilliant-primary/90 text-white rounded-full">
          Get Started
        </Button>
      </div>
    </header>
  );
}
