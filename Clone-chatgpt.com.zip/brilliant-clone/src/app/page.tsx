import { Navbar } from "@/components/Navbar";
import { HeroSection } from "@/components/HeroSection";
import { LearnersSection } from "@/components/LearnersSection";
import { ConceptsSection } from "@/components/ConceptsSection";
import { LearnAtYourLevelSection } from "@/components/LearnAtYourLevelSection";
import { StayMotivatedSection } from "@/components/StayMotivatedSection";
import { GuidedLessonsSection } from "@/components/GuidedLessonsSection";
import { MoreEffectiveSection } from "@/components/MoreEffectiveSection";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <main>
      <Navbar />
      <HeroSection />
      <LearnersSection />
      <ConceptsSection />
      <LearnAtYourLevelSection />
      <StayMotivatedSection />
      <GuidedLessonsSection />
      <MoreEffectiveSection />
      <Footer />
    </main>
  );
}
